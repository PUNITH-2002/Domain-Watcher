from flask import Flask, jsonify
import requests
import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from twilio.rest import Client
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

DOMAIN = "bringway.com"
WHOIS_API_KEY = os.getenv("WHOIS_API_KEY")
SENDGRID_API_KEY = os.getenv("SENDGRID_API_KEY")
TWILIO_SID = os.getenv("TWILIO_SID")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
TWILIO_FROM = os.getenv("TWILIO_FROM")
TWILIO_TO = os.getenv("TWILIO_TO")
EMAIL_TO = os.getenv("EMAIL_TO")

def check_domain():
    url = f"https://www.whoisxmlapi.com/whoisserver/WhoisService?apiKey={WHOIS_API_KEY}&domainName={DOMAIN}&outputFormat=JSON"
    resp = requests.get(url)
    data = resp.json()
    if "REDEMPTIONPERIOD" in str(data).upper():
        return False
    return True

def send_email():
    message = Mail(
        from_email='YOUR_VERIFIED_SENDER@YOURDOMAIN.COM',
        to_emails=EMAIL_TO,
        subject=f"Domain Available: {DOMAIN}",
        plain_text_content=f"Good news! {DOMAIN} is now available to purchase.")
    sg = SendGridAPIClient(SENDGRID_API_KEY)
    sg.send(message)

def send_sms():
    client = Client(TWILIO_SID, TWILIO_AUTH_TOKEN)
    message = client.messages.create(
        body=f"Domain Available: {DOMAIN}",
        from_=TWILIO_FROM,
        to=TWILIO_TO
    )
    print(f"SMS SID: {message.sid}")

@app.route('/')
def index():
    return "Domain Watcher is live!"

@app.route('/domain-status')
def domain_status():
    available = check_domain()
    if available:
        send_email()
        send_sms()
    return jsonify({"domain": DOMAIN, "available": available})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
